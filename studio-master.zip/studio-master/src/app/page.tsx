import EscribaLibroApp from '@/components/escriba-libro-app';

export default function HomePage() {
  return (
    <main>
      <EscribaLibroApp />
    </main>
  );
}
